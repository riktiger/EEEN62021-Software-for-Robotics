from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    cfg = PathJoinSubstitution(
        [FindPackageShare('neo_warrior_launch_pkg'), 'config', 'controller_params.yaml']
    )

    return LaunchDescription([
        Node(
            package='neo_warrior_controller_pkg',
            executable='neo_warrior_controller_node',
            name='neo_warrior_controller_node',
            output='screen',
            parameters=[cfg],
        )
    ])
