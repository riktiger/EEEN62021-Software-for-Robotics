from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='neo_warrior_pkg',
            executable='neo_warrior_node',
            name='neo_warrior_node',
            output='screen'
        )
    ])

