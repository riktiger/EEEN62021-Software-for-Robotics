from setuptools import setup, find_packages
import os
from glob import glob

package_name = 'neo_warrior_launch_pkg'

setup(
    name=package_name,
    version='0.0.0',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
    data_files=[
        ('share/ament_index/resource_index/packages', [os.path.join('resource', package_name)]),
        (os.path.join('share', package_name), ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Aritra Bag',
    maintainer_email='aritra.bag@postgrad.manchester.ac.uk',
    description='Launch package for Neo Warrior robot and controller',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [],
    },
)
