#!/usr/bin/env python3
import math
import time
import rclpy
from rclpy.node import Node

from sfr_coursework1_interface_package.msg import TaskSpacePose, WheelAngularVelocities
from sfr_coursework1_interface_package.srv import TurnRobotOn, TurnRobotOff

WHEEL_RADIUS = 0.05
WHEEL_SEPARATION = 0.3
V_MIN = -0.1
V_MAX = 0.1
T = 0.1  # controller tick (s)

class NeoWarriorController(Node):
    def __init__(self):
        super().__init__('neo_warrior_controller_node')

        # core parameters
        self.declare_parameter('desired_angle_deg', 114.0)
        self.declare_parameter('target_distance_m', 1.0)

        # new, clear parameter names (no backward compatibility)
        self.declare_parameter('maximum_rotation_rate', 0.5)    # rad/s (max body angular speed)
        self.declare_parameter('translation_limit', 0.10)       # m/s (forward linear speed limit)

        # timeouts / durations
        self.declare_parameter('per_phase_timeout_sec', 60.0)
        self.declare_parameter('max_duration_sec', 600.0)

        # read parameters
        self.desired_angle_deg = float(self.get_parameter('desired_angle_deg').value)
        self.desired_angle = math.radians(self.desired_angle_deg)
        self.target_distance_m = float(self.get_parameter('target_distance_m').value)

        self.maximum_rotation_rate = float(self.get_parameter('maximum_rotation_rate').value)
        self.translation_limit = float(self.get_parameter('translation_limit').value)

        self.per_phase_timeout_sec = float(self.get_parameter('per_phase_timeout_sec').value)
        self.max_duration_sec = float(self.get_parameter('max_duration_sec').value)

        self.max_iterations = int(math.ceil(self.max_duration_sec / T))

        # publishers / subscribers / service clients
        self.wheel_pub = self.create_publisher(WheelAngularVelocities, '/neo_warrior/wheel_angular_velocities', 10)
        self.pose_sub = self.create_subscription(TaskSpacePose, '/neo_warrior/task_space_pose', self._pose_cb, 10)
        self.cli_on = self.create_client(TurnRobotOn, '/neo_warrior/turn_robot_on')
        self.cli_off = self.create_client(TurnRobotOff, '/neo_warrior/turn_robot_off')

        # rotation controller gain
        self.declare_parameter('rotation_kp', 0.8)
        self.rotation_kp = float(self.get_parameter('rotation_kp').value)

        # internal state
        self.last_pose = None
        self.pose_received = False
        self.phase = 'init'
        self.iteration_count = 0
        self.phase_start_time = None
        self.forward_start_x = None
        self.forward_start_y = None
        self.forward_start_phi = None
        self.rotation_finish_time = None
        self.final_pose = None
        self.forward_finish_time = None
        self._rotation_duration = 0.0

        self.create_timer(T, lambda: None)
        self.get_logger().info(
            f'Controller started (desired_angle_deg={self.desired_angle_deg}, target_distance_m={self.target_distance_m})'
        )
        self.get_logger().info(
            f'maximum_rotation_rate={self.maximum_rotation_rate} rad/s, translation_limit={self.translation_limit} m/s'
        )

    def _pose_cb(self, msg: TaskSpacePose):
        self.last_pose = msg
        self.pose_received = True

    def _wait_for_service_and_call_on(self) -> bool:
        self.get_logger().info('Waiting for /neo_warrior/turn_robot_on service...')
        last_log = time.time()
        while rclpy.ok():
            if self.cli_on.wait_for_service(timeout_sec=0.5):
                try:
                    req = TurnRobotOn.Request()
                    fut = self.cli_on.call_async(req)
                    rclpy.spin_until_future_complete(self, fut, timeout_sec=2.0)
                    if fut.done() and fut.result() is not None and getattr(fut.result(), 'success', False):
                        self.get_logger().info('Called /neo_warrior/turn_robot_on -> success=True')
                        return True
                    else:
                        self.get_logger().info('Called /neo_warrior/turn_robot_on -> success=False or no response')
                except Exception as e:
                    self.get_logger().error(f'Error calling turn_robot_on: {e}')
            if time.time() - last_log > 5.0:
                last_log = time.time()
                self.get_logger().info('Still waiting for /neo_warrior/turn_robot_on service...')
            rclpy.spin_once(self, timeout_sec=0.05)
        return False

    def _call_turn_off(self) -> bool:
        if not self.cli_off.wait_for_service(timeout_sec=1.0):
            return False
        try:
            req = TurnRobotOff.Request()
            fut = self.cli_off.call_async(req)
            rclpy.spin_until_future_complete(self, fut, timeout_sec=2.0)
            if fut.done() and fut.result() is not None:
                self.get_logger().info(f'Called /neo_warrior/turn_robot_off -> success={bool(fut.result().success)}')
                return bool(fut.result().success)
        except Exception as e:
            self.get_logger().error(f'Error calling turn_robot_off: {e}')
        return False

    def _publish_wheel_angulars_from_linear(self, v_l, v_r):
        # clamp linear velocities to allowed limits, then convert to wheel angular velocities
        v_l_c = max(V_MIN, min(V_MAX, v_l))
        v_r_c = max(V_MIN, min(V_MAX, v_r))
        omega_l = v_l_c / WHEEL_RADIUS
        omega_r = v_r_c / WHEEL_RADIUS
        m = WheelAngularVelocities()
        m.left_wheel_angular_velocity = float(omega_l)
        m.right_wheel_angular_velocity = float(omega_r)
        self.wheel_pub.publish(m)

    def _shortest_angular_diff(self, target, current):
        return (target - current + math.pi) % (2.0 * math.pi) - math.pi

    def step(self):
        self.iteration_count += 1
        if self.iteration_count > self.max_iterations:
            self._publish_wheel_angulars_from_linear(0.0, 0.0)
            self._call_turn_off()
            self.get_logger().error('robot failed to reach destination within the specified time limit')
            self.phase = 'timeout'
            return

        if self.phase == 'init':
            ok = self._wait_for_service_and_call_on()
            if not ok:
                return
            self.phase = 'rotate'
            self.phase_start_time = time.time()
            return

        if self.phase == 'rotate':
            if not self.pose_received:
                return
            current_phi = float(self.last_pose.phi_z)
            ang_err = self._shortest_angular_diff(self.desired_angle, current_phi)
            ang_tol = math.radians(0.0001)

            
            omega_cmd_max = float(self.maximum_rotation_rate)
            omega_body_max = 2.0 * V_MAX / WHEEL_SEPARATION
            omega_cmd_max = min(omega_cmd_max, omega_body_max)

            omega_p = self.rotation_kp * ang_err
            omega_min = 1e-4
            omega_use = max(-omega_cmd_max, min(omega_cmd_max, omega_p))
            if abs(omega_use) < omega_min and abs(ang_err) > ang_tol:
                omega_use = math.copysign(omega_min, ang_err)

            v_r = (omega_use * WHEEL_SEPARATION) / 2.0
            v_l = -v_r
            self._publish_wheel_angulars_from_linear(v_l, v_r)

            if abs(ang_err) <= ang_tol:
                self._publish_wheel_angulars_from_linear(0.0, 0.0)
                self.rotation_finish_time = time.time()
                rotation_duration = self.rotation_finish_time - (self.phase_start_time or self.rotation_finish_time)
                self.get_logger().info(f'Rotation completed in {rotation_duration:.6f} s (ang_err={ang_err:.9f} rad)')
                self._rotation_duration = rotation_duration
                self.phase = 'forward'
                self.phase_start_time = time.time()
                self.forward_start_x = float(self.last_pose.x)
                self.forward_start_y = float(self.last_pose.y)
                self.forward_start_phi = float(self.last_pose.phi_z)
                self.get_logger().info(f'Forward phase starting at x={self.forward_start_x:.6f} m, y={self.forward_start_y:.6f} m, phi={self.forward_start_phi:.6f} rad')
                return

            if (time.time() - (self.phase_start_time or time.time())) > self.per_phase_timeout_sec:
                self.get_logger().error('rotation phase exceeded timeout')
                self._publish_wheel_angulars_from_linear(0.0, 0.0)
                self._call_turn_off()
                self.phase = 'timeout'
            return

        if self.phase == 'forward':
            if not self.pose_received:
                return
            if self.phase_start_time is None:
                self.phase_start_time = time.time()
                v_cmd = max(V_MIN, min(V_MAX, float(self.translation_limit)))
                self._publish_wheel_angulars_from_linear(v_cmd, v_cmd)

            cur_x = float(self.last_pose.x)
            cur_y = float(self.last_pose.y)

            dx = cur_x - self.forward_start_x
            dy = cur_y - self.forward_start_y
            dist = math.hypot(dx, dy)

            dist_tol = 0.001
            if dist + 1e-12 >= self.target_distance_m - dist_tol:
                self._publish_wheel_angulars_from_linear(0.0, 0.0)
                self.forward_finish_time = time.time()
                forward_duration = self.forward_finish_time - (self.phase_start_time or self.forward_finish_time)
                self.get_logger().info(f'Forward segment completed in {forward_duration:.6f} s')
                ok = self._call_turn_off()
                if not ok:
                    self.get_logger().warn('TurnRobotOff returned False or no response after forward completion')
                final_x = round(float(self.last_pose.x), 4)
                final_y = round(float(self.last_pose.y), 4)
                final_phi_rad = float(self.last_pose.phi_z)
                final_phi_deg = round(math.degrees(final_phi_rad), 4)
                dist_from_origin = round(math.hypot(final_x, final_y), 4)
                elapsed_since_rotation = self.forward_finish_time - (self.rotation_finish_time or self.forward_finish_time)
                self.final_pose = (final_x, final_y, final_phi_rad)
                self.get_logger().info(f'FINAL POSE: x={final_x:.4f} m, y={final_y:.4f} m, phi_z={final_phi_rad:.6f} rad')
                self.get_logger().info(f'Distance from origin: {dist_from_origin:.3f} m; Angle: {final_phi_rad:.6f} rad ({final_phi_deg:.4f} deg)')
                self.get_logger().info(f'Time since rotation to forward completion: {elapsed_since_rotation:.6f} s')
                self.phase = 'done'
                return

            if (time.time() - (self.phase_start_time or time.time())) > self.per_phase_timeout_sec:
                self.get_logger().error('forward phase exceeded timeout')
                self._publish_wheel_angulars_from_linear(0.0, 0.0)
                self._call_turn_off()
                self.phase = 'timeout'
                return

            v_cmd = max(V_MIN, min(V_MAX, float(self.translation_limit)))
            self._publish_wheel_angulars_from_linear(v_cmd, v_cmd)
            return

        if self.phase in ('done', 'timeout'):
            self._publish_wheel_angulars_from_linear(0.0, 0.0)
            return

def main(args=None):
    rclpy.init(args=args)
    node = NeoWarriorController()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            node.step()
            if node.phase in ('done', 'timeout'):
                time.sleep(0.05)
                break
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)
    finally:
        node.get_logger().info('Controller exiting')

if __name__ == '__main__':
    main()
