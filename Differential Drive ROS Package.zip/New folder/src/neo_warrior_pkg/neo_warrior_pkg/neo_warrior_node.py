#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node

from sfr_coursework1_interface_package.msg import TaskSpacePose, WheelAngularVelocities
from sfr_coursework1_interface_package.srv import TurnRobotOn, TurnRobotOff

WHEEL_RADIUS = 0.05
WHEEL_SEPARATION = 0.3
V_MIN = -0.1
V_MAX = 0.1
T = 0.1  # seconds (10 Hz)

class NeoWarriorNode(Node):
    def __init__(self) -> None:
        super().__init__('neo_warrior_node')
        self.state: str = 'OFF'
        self.shutdown_started: bool = False

        self.px = 0.0
        self.py = 0.0
        self.phi_z = 0.0

        self.last_cmd_left = 0.0
        self.last_cmd_right = 0.0

        self.w_left = 0.0
        self.w_right = 0.0
        self.v_left = 0.0
        self.v_right = 0.0

        self._last_turn_on_response = None
        self._last_turn_off_response = None

        qos_depth = 1
        self.pose_publisher = self.create_publisher(TaskSpacePose, '/neo_warrior/task_space_pose', qos_depth)
        self.wheel_subscriber = self.create_subscription(
            WheelAngularVelocities,
            '/neo_warrior/wheel_angular_velocities',
            self.wheel_cmd_cb,
            qos_depth
        )
        self.turn_on_server = self.create_service(TurnRobotOn, '/neo_warrior/turn_robot_on', self.handle_turn_on)
        self.turn_off_server = self.create_service(TurnRobotOff, '/neo_warrior/turn_robot_off', self.handle_turn_off)

        self.update_timer = self.create_timer(T, self.update_callback)
        self.publisher_timer = self.create_timer(T, self.publisher_callback)

        self.get_logger().info('neo_warrior_node initialized (state=OFF)')

    def handle_turn_on(self, request, response) -> TurnRobotOn.Response:
        if self.state == 'OFF':
            response.success = True
            self.state = 'ON'
            self._last_turn_on_response = True
            try:
                self.get_logger().info('Turning from OFF -> ON (/neo_warrior/turn_robot_on -> success)')
            except Exception:
                pass
        else:
            response.success = False
            self._last_turn_on_response = False
            try:
                self.get_logger().info('Turning from OFF -> ON (/neo_warrior/turn_robot_on -> failure)')
            except Exception:
                pass
        return response

    def handle_turn_off(self, request, response) -> TurnRobotOff.Response:
        if self.state == 'ON':
            response.success = True
            self.state = 'OFF'
            self.w_left = self.w_right = self.v_left = self.v_right = 0.0
            self.last_cmd_left = self.last_cmd_right = 0.0
            self._last_turn_off_response = True
            try:
                px_r = round(self.px, 4)
                py_r = round(self.py, 4)
                phi_r = self.phi_z  # keep radians original for the "radians" field
                deg_r = round(math.degrees(phi_r), 4)
                dist = round(math.hypot(self.px, self.py), 4)
                self.get_logger().info(f'Turning from ON -> OFF (/neo_warrior/turn_robot_off -> success)')
                self.get_logger().info(f'FINAL POSE: x={px_r:.4f} m y={py_r:.4f} m phi_z={phi_r:.6f} rad')
                self.get_logger().info(f'Distance from origin: {dist:.3f} m; Angle: {phi_r:.6f} rad ({deg_r:.4f} deg)')
            except Exception:
                pass
        else:
            response.success = False
            self._last_turn_off_response = False
            try:
                self.get_logger().info('Turning from ON -> OFF (/neo_warrior/turn_robot_off -> failure)')
            except Exception:
                pass
        return response

    def wheel_cmd_cb(self, msg: WheelAngularVelocities) -> None:
        if self.state != 'ON' or self.shutdown_started:
            return
        try:
            self.last_cmd_left = float(msg.left_wheel_angular_velocity)
            self.last_cmd_right = float(msg.right_wheel_angular_velocity)
        except Exception:
            pass

    def update_callback(self) -> None:
        if self.state != 'ON' or self.shutdown_started:
            return
        try:
            cmd_left = self.last_cmd_left
            cmd_right = self.last_cmd_right

            v_left_raw = cmd_left * WHEEL_RADIUS
            v_right_raw = cmd_right * WHEEL_RADIUS

            v_left_clamped = max(V_MIN, min(V_MAX, v_left_raw))
            v_right_clamped = max(V_MIN, min(V_MAX, v_right_raw))

            self.w_left = cmd_left
            self.w_right = cmd_right
            self.v_left = v_left_clamped
            self.v_right = v_right_clamped

            v = 0.5 * (v_left_clamped + v_right_clamped)
            omega = (v_right_clamped - v_left_clamped) / WHEEL_SEPARATION

            self.px += v * math.cos(self.phi_z) * T
            self.py += v * math.sin(self.phi_z) * T
            self.phi_z += omega * T

            self.phi_z = (self.phi_z + math.pi) % (2.0 * math.pi) - math.pi
        except Exception:
            pass

    def publisher_callback(self) -> None:
        if self.state == 'ON' and not self.shutdown_started:
            msg = TaskSpacePose()
            msg.x = self.px
            msg.y = self.py
            msg.phi_z = self.phi_z
            self.pose_publisher.publish(msg)
            try:
                self.get_logger().info(f'neo_warrior: Current Pose : x = {msg.x:.6f} m, y = {msg.y:.6f} m, phi_z = {msg.phi_z:.6f} rad')
            except Exception:
                pass


def main(args=None) -> None:
    rclpy.init(args=args)
    node = NeoWarriorNode()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass
    except Exception as e:
            print(e)

if __name__ == '__main__':
    main()
