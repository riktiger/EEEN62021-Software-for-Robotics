
#!/usr/bin/env python3

import time
import math
import argparse
import yaml
from ament_index_python.packages import get_package_share_directory
import os

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from action_msgs.msg import GoalStatus

from geometry_msgs.msg import PoseStamped
from sfr_coursework2_interface_package.action import DroneControl


def quat_to_yaw(qx, qy, qz, qw):
    return math.atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz))


def pose_distance(pose_a, pose_b):
    dx = pose_a.position.x - pose_b.position.x
    dy = pose_a.position.y - pose_b.position.y
    dz = pose_a.position.z - pose_b.position.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def load_goal_from_yaml(path):
    with open(path, 'r') as f:
        cfg = yaml.safe_load(f)
    frame_id = cfg.get('frame_id', 'shapes')
    pos = cfg.get('position', {})
    ori = cfg.get('orientation', {})
    x = float(pos.get('x', 0.0))
    y = float(pos.get('y', 0.0))
    z = float(pos.get('z', 0.0))
    qx = float(ori.get('x', 0.0))
    qy = float(ori.get('y', 0.0))
    qz = float(ori.get('z', 0.0))
    qw = float(ori.get('w', 1.0))
    return frame_id, x, y, z, qx, qy, qz, qw


class AlphaSentinelClientNode(Node):
    def __init__(self, server_name: str):
        super().__init__('alpha_sentinel_client')
        self.client = ActionClient(self, DroneControl, server_name)
        self.last_feedback_pose = None
        self.goal_pose = None

    def build_goal(self, frame_id, x, y, z, qx, qy, qz, qw):
        ps = PoseStamped()
        ps.header.frame_id = frame_id
        ps.pose.position.x = x
        ps.pose.position.y = y
        ps.pose.position.z = z
        ps.pose.orientation.x = qx
        ps.pose.orientation.y = qy
        ps.pose.orientation.z = qz
        ps.pose.orientation.w = qw
        goal = DroneControl.Goal()
        goal.desired_pose = ps
        return goal

    def feedback_cb(self, feedback_msg):
        fb = feedback_msg.feedback
        self.last_feedback_pose = fb.current_pose.pose
        cp = self.last_feedback_pose
        yaw = quat_to_yaw(cp.orientation.x, cp.orientation.y, cp.orientation.z, cp.orientation.w)
        dist = pose_distance(cp, self.goal_pose)
        self.get_logger().info(
            f"Feedback | Pose: x={cp.position.x:.3f}, y={cp.position.y:.3f}, z={cp.position.z:.3f}, yaw={yaw:.3f} rad | Distance to goal: {dist:.4f} m"
        )

    def send_once(self, goal_msg: DroneControl.Goal, timeout_sec: float = 10.0):
        if not self.client.wait_for_server(timeout_sec=timeout_sec):
            self.get_logger().error('Action server not available')
            return False, None
        self.goal_pose = goal_msg.desired_pose.pose
        send_future = self.client.send_goal_async(goal_msg, feedback_callback=self.feedback_cb)
        rclpy.spin_until_future_complete(self, send_future)
        goal_handle = send_future.result()
        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().warn('Goal rejected')
            return False, None
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        result = result_future.result()
        success = (result.status == GoalStatus.STATUS_SUCCEEDED)
        return success, result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', '-c', default='', help='Path to YAML; default uses installed share/configs/goal.yaml')
    parser.add_argument('--server', '-s', default='alpha_sentinel/set_pose')
    parser.add_argument('--max-attempts', type=int, default=4)
    args = parser.parse_args()

    rclpy.init()
    node = AlphaSentinelClientNode(args.server)

    if args.config:
        config_path = args.config
    else:
        share_dir = get_package_share_directory('alpha_sentinel_controller_pkg')
        config_path = os.path.join(share_dir, 'configs', 'goal.yaml')

    frame_id, tx, ty, tz, qx, qy, qz, qw = load_goal_from_yaml(config_path)
    goal_msg = node.build_goal(frame_id, tx, ty, tz, qx, qy, qz, qw)

    final_error = None
    attempts = min(args.max_attempts, 4)

    for i in range(attempts):
        node.get_logger().info(
            f"Attempt {i+1}/{attempts} sending goal to ({tx:.3f}, {ty:.3f}, {tz:.3f}) in frame '{frame_id}'"
        )
        success, _ = node.send_once(goal_msg)

        if node.last_feedback_pose is not None:
            final_error = pose_distance(node.last_feedback_pose, goal_msg.desired_pose.pose)
            yaw = quat_to_yaw(
                node.last_feedback_pose.orientation.x,
                node.last_feedback_pose.orientation.y,
                node.last_feedback_pose.orientation.z,
                node.last_feedback_pose.orientation.w
            )
            node.get_logger().info(
                f"Post-attempt pose | x={node.last_feedback_pose.position.x:.3f}, "
                f"y={node.last_feedback_pose.position.y:.3f}, "
                f"z={node.last_feedback_pose.position.z:.3f}, "
                f"yaw={yaw:.3f} rad | Remaining distance: {final_error:.4f} m"
            )

        if success:
            node.get_logger().info('Goal reached — breaking out early.')
            break

        if i < attempts - 1:
            time.sleep(2.0)

    if final_error is None:
        print('Final distance error: N/A (no feedback received)')
    else:
        print(f"Final distance error: {final_error:.4f} m")


if __name__ == '__main__':
    main()
