
#!/usr/bin/env python3

import time
import math

import rclpy
from rclpy.action import ActionServer
from rclpy.action.server import ServerGoalHandle
from rclpy.node import Node

from geometry_msgs.msg import Twist
from tf2_ros import Buffer, TransformListener
from rclpy.duration import Duration
from rclpy.time import Time

from sfr_coursework2_interface_package.action import DroneControl


class AlphaSentinelControllerNode(Node):
    def __init__(self):
        super().__init__('alpha_sentinel_controller_node')

        self.MAX_ITERATIONS = 500
        self.sampling_time = 0.01
        self.kp = 0.8
        self.tolerance = 0.05
        self.linear_velocity = 0.5
        self.angular_velocity = 0.8

        self.current_transform = None
        
        self.active_goal = None
        self.goal_pose = None
        self.iteration_count = 0

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.cmd_vel_publisher = self.create_publisher(
            Twist,
            '/model/box/cmd_vel',
            10
        )
        
        self.tf_timer = self.create_timer(self.sampling_time, self.control_timer_callback)
        
        self.action_server = ActionServer(
            self,
            DroneControl,
            'alpha_sentinel/set_pose',
            self.execute_callback
        )
        
        self.get_logger().info('Alpha Sentinel Controller Node initialized')

    def control_timer_callback(self):
        try:
            self.current_transform = self.tf_buffer.lookup_transform(
                'shapes',
                'box',
                Time()
            )
        except Exception:
            pass
        
        if self.active_goal is None or self.goal_pose is None:
            return
        
        if not self.active_goal.is_active:
            self.stop_motion()
            self.active_goal = None
            self.goal_pose = None
            return
        
        if self.current_transform is None:
            return
        
        distance = self.get_distance(self.current_transform, self.goal_pose)
        
        feedback_msg = DroneControl.Feedback()
        feedback_msg.current_pose.header.stamp = self.get_clock().now().to_msg()
        feedback_msg.current_pose.header.frame_id = 'shapes'
        feedback_msg.current_pose.pose.position.x = self.current_transform.transform.translation.x
        feedback_msg.current_pose.pose.position.y = self.current_transform.transform.translation.y
        feedback_msg.current_pose.pose.position.z = self.current_transform.transform.translation.z
        feedback_msg.current_pose.pose.orientation = self.current_transform.transform.rotation
        self.active_goal.publish_feedback(feedback_msg)
        
        if self.iteration_count % 100 == 0:
            x = self.current_transform.transform.translation.x
            y = self.current_transform.transform.translation.y
            z = self.current_transform.transform.translation.z
            qx = self.current_transform.transform.rotation.x
            qy = self.current_transform.transform.rotation.y
            qz = self.current_transform.transform.rotation.z
            qw = self.current_transform.transform.rotation.w
            yaw = math.atan2(2*(qw*qz + qx*qy), 1 - 2*(qy*qy + qz*qz))
            self.get_logger().info(f'Distance to goal: {distance:.4f}m | Pose: x={x:.3f}, y={y:.3f}, z={z:.3f}, yaw={yaw:.3f} rad')
        
        if distance <= self.tolerance:
            self.get_logger().info(f'Goal reached! Distance: {distance:.4f}m')
            self.stop_motion()
            self.active_goal.succeed()
            self.active_goal = None
            self.goal_pose = None
            return
        
        if self.iteration_count >= self.MAX_ITERATIONS:
            self.get_logger().warn('Action timed out after 5 seconds, GOAL ABORTED. Recall Action to continue.')
            self.stop_motion()
            self.active_goal.abort()
            self.active_goal = None
            self.goal_pose = None
            return
        
        cmd_vel = self.compute_velocity_command(self.current_transform, self.goal_pose)
        self.cmd_vel_publisher.publish(cmd_vel)
        
        self.iteration_count += 1

    def stop_motion(self):
        stop_cmd = Twist()
        self.cmd_vel_publisher.publish(stop_cmd)

    def get_distance(self, current_transform, goal_pose):
        if current_transform is None:
            return float('inf')
        
        dx = current_transform.transform.translation.x - goal_pose.position.x
        dy = current_transform.transform.translation.y - goal_pose.position.y
        dz = current_transform.transform.translation.z - goal_pose.position.z
        
        return math.sqrt(dx*dx + dy*dy + dz*dz)

    def compute_velocity_command(self, current_transform, goal_pose):
        if current_transform is None:
            return Twist()
        
        error_x = goal_pose.position.x - current_transform.transform.translation.x
        error_y = goal_pose.position.y - current_transform.transform.translation.y
        error_z = goal_pose.position.z - current_transform.transform.translation.z
        
        cmd_vel = Twist()
        cmd_vel.linear.x = self.kp * error_x
        cmd_vel.linear.y = self.kp * error_y
        cmd_vel.linear.z = self.kp * error_z
        
        cmd_vel.linear.x = max(-self.linear_velocity, min(self.linear_velocity, cmd_vel.linear.x))
        cmd_vel.linear.y = max(-self.linear_velocity, min(self.linear_velocity, cmd_vel.linear.y))
        cmd_vel.linear.z = max(-self.linear_velocity, min(self.linear_velocity, cmd_vel.linear.z))
        
        cmd_vel.angular.x = 0.00        
        cmd_vel.angular.y = 0.00        
        cmd_vel.angular.z = max(-self.angular_velocity, min(self.angular_velocity, 0.0))
        
        return cmd_vel

    def execute_callback(self, goal_handle: ServerGoalHandle) -> DroneControl.Result:
        self.goal_pose = goal_handle.request.desired_pose.pose
        self.active_goal = goal_handle
        self.iteration_count = 0
        
        self.get_logger().info(f'Goal position: ({self.goal_pose.position.x:.2f}, '
                               f'{self.goal_pose.position.y:.2f}, {self.goal_pose.position.z:.2f})')
        
        while rclpy.ok() and goal_handle.is_active and self.active_goal is not None:
            rclpy.spin_once(self, timeout_sec=0.1)
        
        result = DroneControl.Result()
        result.success = (goal_handle.status == 4)
        
        return result

def main(args=None):
    try:
        rclpy.init(args=args)
        node = AlphaSentinelControllerNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
