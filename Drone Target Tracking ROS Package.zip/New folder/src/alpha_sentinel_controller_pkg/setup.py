
from setuptools import find_packages, setup

package_name = 'alpha_sentinel_controller_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/configs', ['configs/goal.yaml']),
    ],
    install_requires=[
        'setuptools',
        'PyYAML',
    ],
    zip_safe=True,
    maintainer='aritrabag@14320390',
    maintainer_email='aritra.bag@postgrad.manchester.ac.uk',
    description='The setup file for the Alpha Sentinels Controller and Client Nodes',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'alpha_sentinel_controller_node = alpha_sentinel_controller_pkg.alpha_sentinel_controller_node:main',
            'alpha_sentinel_client_node = alpha_sentinel_controller_pkg.alpha_sentinel_client_node:main',
        ],
    },
)

