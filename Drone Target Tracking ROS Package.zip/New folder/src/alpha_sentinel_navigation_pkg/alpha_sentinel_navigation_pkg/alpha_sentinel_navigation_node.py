
import math
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped, Pose
from rclpy.action import ActionClient
from rclpy.action.client import ClientGoalHandle
from rclpy.task import Future
from nav2_msgs.action import NavigateToPose
from rcl_interfaces.srv import SetParameters
from rcl_interfaces.msg import Parameter as ROSParam, ParameterValue, ParameterType


class AlphaSentinelNavigationNode(Node):

    def __init__(self):
        super().__init__('alpha_sentinel_navigation_node')

        self.initial_pose = Pose()
        self.initial_pose.position.x = 0.0
        self.initial_pose.position.y = 0.0
        self.initial_pose.position.z = 0.0
        self.initial_pose.orientation.w = 1.0

        self.goal_1_pose = Pose()
        self.goal_1_pose.position.x = 21.87
        self.goal_1_pose.position.y = -7.07
        self.goal_1_pose.position.z = 0.0
        self.goal_1_pose.orientation.w = 1.0

        self._initial_pose_topic = '/initialpose'
        self.initial_pose_publisher = self.create_publisher(
            PoseWithCovarianceStamped, self._initial_pose_topic, 1
        )

        while self.count_subscribers(self._initial_pose_topic) < 1:
            self.get_logger().info(
                f"Waiting for a subscriber on {self._initial_pose_topic} (AMCL)..."
            )
            time.sleep(0.1)

        self.action_client = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.get_result_future = None
        self.goal_handle: ClientGoalHandle | None = None
        self.current_goal_name = ""
        self.active_goal_pose: Pose | None = None

        self.current_pose: Pose | None = None
        self.amcl_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self.amcl_pose_callback, 1
        )

        self.pose_log_timer = self.create_timer(0.01, self.log_current_pose)

        self.deadline_timer = None
        self.mission_start_monotonic = None
        self.resend_timer = None

        self.goal_start_monotonic = None
        self.goal_timer = None

    def amcl_pose_callback(self, msg: PoseWithCovarianceStamped) -> None:
        self.current_pose = msg.pose.pose

    def log_current_pose(self) -> None:
        if self.current_pose is None:
            self.get_logger().info("Current pose: not available yet (waiting for /amcl_pose).")
            return
        p = self.current_pose.position
        q = self.current_pose.orientation
        yaw = math.atan2(2.0 * (q.w * q.z), 1.0 - 2.0 * (q.z * q.z))
        self.get_logger().info(
            f"Current pose → x: {p.x:.4f}, y: {p.y:.4f}, z: {p.z:.4f}, yaw: {yaw:.3f} rad"
        )

    def send_initial_pose(self) -> None:
        self.get_logger().info("Publishing initial pose.")
        pwcs = PoseWithCovarianceStamped()
        pwcs.header.stamp = self.get_clock().now().to_msg()
        pwcs.header.frame_id = 'map'
        pwcs.pose.pose = self.initial_pose
        pwcs.pose.covariance[:] = [0.0] * 36
        pwcs.pose.covariance[0] = 0.25
        pwcs.pose.covariance[7] = 0.25
        pwcs.pose.covariance[14] = 0.25
        pwcs.pose.covariance[21] = 0.0
        pwcs.pose.covariance[28] = 0.0
        pwcs.pose.covariance[35] = 0.068
        self.initial_pose_publisher.publish(pwcs)
        self.get_logger().info("Initial pose published successfully with specified covariance.")
        if self.mission_start_monotonic is None:
            self.mission_start_monotonic = time.monotonic()
            if self.deadline_timer is None:
                self.deadline_timer = self.create_timer(0.01, self.check_goal_deadline)

    def send_goal_async(self, desired_pose: Pose, goal_name: str) -> None:
        self.current_goal_name = goal_name
        self.active_goal_pose = desired_pose
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.pose = desired_pose
        while not self.action_client.wait_for_server(timeout_sec=1.0):
            self.get_logger().info(
                f'Action server {self.action_client._action_name} not available, waiting...'
            )
        self.get_logger().info(f'Sending goal: {goal_name}.')
        send_goal_future = self.action_client.send_goal_async(
            goal_msg, feedback_callback=self.action_feedback_callback
        )
        send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future: Future) -> None:
        goal: ClientGoalHandle = future.result()
        if not goal.accepted:
            self.get_logger().info(f'Goal "{self.current_goal_name}" was rejected by the server. Retrying...')
            if self.resend_timer is None:
                self.resend_timer = self.create_timer(
                    2.0, lambda: self.send_goal_async(self.active_goal_pose, self.current_goal_name)
                )
            return
        self.get_logger().info(f'Goal "{self.current_goal_name}" was accepted by the server.')
        self.goal_handle = goal
        if self.resend_timer is not None:
            self.resend_timer.cancel()
            self.resend_timer = None
        self.get_result_future = goal.get_result_async()
        self.get_result_future.add_done_callback(self.action_result_callback)
        if self.goal_start_monotonic is None:
            self.goal_start_monotonic = time.monotonic()
            if self.goal_timer is None:
                self.goal_timer = self.create_timer(0.01, self.check_goal_time)

    def check_goal_deadline(self) -> None:
        if self.mission_start_monotonic is None:
            return
        elapsed = time.monotonic() - self.mission_start_monotonic
        return

    def check_goal_time(self) -> None:
        if self.goal_start_monotonic is None:
            return
        _ = time.monotonic() - self.goal_start_monotonic
        return

    def action_result_callback(self, future: Future) -> None:
        res = future.result()
        status = res.status
        self.get_logger().info(f'Goal "{self.current_goal_name}" finished with status: {status}')

        elapsed_initial = 0.0
        if self.mission_start_monotonic is not None:
            elapsed_initial = time.monotonic() - self.mission_start_monotonic
        elapsed_goal = 0.0
        if self.goal_start_monotonic is not None:
            elapsed_goal = time.monotonic() - self.goal_start_monotonic

        final_pose_str = "unknown"
        d_err = None
        if self.current_pose is not None:
            final_pose_str = f"x: {self.current_pose.position.x:.3f}, y: {self.current_pose.position.y:.3f}"
            if self.active_goal_pose is not None:
                dx = self.active_goal_pose.position.x - self.current_pose.position.x
                dy = self.active_goal_pose.position.y - self.current_pose.position.y
                d_err = math.hypot(dx, dy)

        tol_pct_str = "unknown"
        if d_err is not None:
            tol_pct = max(0.0, min(100.0, (0.5 - d_err) / 0.5 * 100.0))
            tol_pct_str = f"{tol_pct:.1f}% (error: {d_err:.3f} m)"

        self.get_logger().info(
            f'Seconds since initial pose: {elapsed_initial:.3f}; Seconds since goal set: {elapsed_goal:.3f}; '
            f'Final pose → {final_pose_str}; Reference goal → x: {self.active_goal_pose.position.x:.3f}, '
            f'y: {self.active_goal_pose.position.y:.3f}; Tolerance (0.5 m) → {tol_pct_str}'
        )

        if self.pose_log_timer is not None:
            self.pose_log_timer.cancel()
        if self.deadline_timer is not None:
            self.deadline_timer.cancel()
        if self.goal_timer is not None:
            self.goal_timer.cancel()
        if self.resend_timer is not None:
            self.resend_timer.cancel()
            self.resend_timer = None
        self.destroy_node()
        rclpy.shutdown()

    def action_feedback_callback(self, feedback_msg: NavigateToPose.Feedback) -> None:
        feedback = feedback_msg.feedback
        self.get_logger().info(
            f'Feedback: distance to goal "{self.current_goal_name}": {feedback.distance_remaining:.2f} m'
        )

    def apply_nav2_speed_tweaks(self) -> None:
        tweaks = [
            ('/controller_server', {
                'max_vel_x': 2.00,
                'max_vel_y': 2.00,
                'max_vel_theta':2.00,
                'min_vel_x': 0.10,
                'min_vel_y': 0.10,
                'min_vel_theta':0.10

            })]
        for target, params in tweaks:
            client = self.create_client(SetParameters, f'{target}/set_parameters')
            while not client.wait_for_service(timeout_sec=1.0):
                self.get_logger().info(f'Waiting for {target}/set_parameters...')
                time.sleep(0.2)
            req = SetParameters.Request()
            req.parameters = []
            for name, val in params.items():
                pv = ParameterValue()
                if isinstance(val, bool):
                    pv.type = ParameterType.PARAMETER_BOOL
                    pv.bool_value = val
                elif isinstance(val, int):
                    pv.type = ParameterType.PARAMETER_INTEGER
                    pv.integer_value = val
                elif isinstance(val, float):
                    pv.type = ParameterType.PARAMETER_DOUBLE
                    pv.double_value = val
                else:
                    pv.type = ParameterType.PARAMETER_STRING
                    pv.string_value = str(val)
                req.parameters.append(ROSParam(name=name, value=pv))
            fut = client.call_async(req)
            rclpy.spin_until_future_complete(self, fut)
            if fut.result() is not None:
                results = fut.result().results
                ok = all(r.successful for r in results)
                if ok:
                    self.get_logger().info(f'{target} parameters applied.')
                else:
                    self.get_logger().warning(f'{target} parameter application had failures.')
            else:
                self.get_logger().error(f'{target} parameter service call failed.')

def main(args=None):
    try:
        rclpy.init(args=args)
        node = AlphaSentinelNavigationNode()
        node.apply_nav2_speed_tweaks()
        node.send_initial_pose()
        node.send_goal_async(node.goal_1_pose, "Goal")
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f'Unexpected error: {e}')


if __name__ == '__main__':
    main()