
from launch import LaunchDescription
from launch_ros.actions import Node, SetParameter

def generate_launch_description():
    bridges = [
        # (i) ROS2 -> Gazebo
        '/model/box/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist',

        # (ii) (iii) (iv) Gazebo -> ROS2 (Pose_V -> TFMessage)
        '/model/box/pose@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',
        '/model/target_0/pose@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',
        '/model/target_1/pose@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',

        # Optional extras (both Gazebo -> ROS2)
        '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
        '/model/box/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry',
    ]

    bridge_node = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='ros_gz_bridge',
        output='screen',
        arguments=bridges,
        remappings=[
            # Map ROS-side topics for pose bridges to /tf
            ('/model/box/pose', '/tf'),
            ('/model/target_0/pose', '/tf'),
            ('/model/target_1/pose', '/tf'),
        ],
       )

    return LaunchDescription([
        SetParameter(name='use_sim_time', value=True),
        bridge_node,])
