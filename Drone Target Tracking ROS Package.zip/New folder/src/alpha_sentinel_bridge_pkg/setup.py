
from setuptools import find_packages, setup

package_name = 'alpha_sentinel_bridge_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', [
            'launch/alpha_sentinel_bridge_launch.py',
        ]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aritrabag@14320390',
    maintainer_email='aritra.bag@postgrad.manchester.ac.uk',
    description='ROS-GZ single-direction bridges for flying box',
    license='Apache-2.0',
    extras_require={'test': ['pytest']},
    entry_points={'console_scripts': []},
)